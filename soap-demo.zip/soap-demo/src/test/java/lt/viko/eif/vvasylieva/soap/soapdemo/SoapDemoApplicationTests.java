package lt.viko.eif.vvasylieva.soap.soapdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoapDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
